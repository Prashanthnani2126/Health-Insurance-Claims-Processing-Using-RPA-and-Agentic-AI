# The confidence gateway is enforced after either AI implementation returns.
from app.ai_agent.medical_agent import review_medical_necessity
from app.database.database import create_human_review, save_ai_decision, save_audit_log
from app.models.claim import InsuranceClaim
from app.models.results import AIDecision
from config import settings


def run_ai_workflow(claim: InsuranceClaim) -> AIDecision:
    # Capture prompt and model metadata for the permanent audit trail.
    decision, prompt, model_name = review_medical_necessity(claim)
    if decision.decision != "Escalate" and decision.confidence < settings.confidence_threshold:
        # Low confidence overrides an otherwise automatic recommendation.
        decision = decision.model_copy(
            update={
                "decision": "Escalate",
                "reasoning": decision.reasoning + " Confidence is below the configured automatic-decision threshold.",
                "recommended_action": "Send the claim to a qualified human reviewer.",
                "risk_flags": decision.risk_flags + ["Low confidence"],
            }
        )
    decision_id = save_ai_decision(
        claim.claim_id, decision,
        prompt_summary=prompt[:1000],
        model_name=model_name,
    )
    save_audit_log(claim.claim_id, "AI Agent", decision.decision, decision.reasoning)
    if decision.decision == "Escalate":
        # Queue creation preserves the linked original recommendation.
        create_human_review(claim.claim_id, decision_id)
    return decision
