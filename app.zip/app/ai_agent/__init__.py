# Medical-necessity assessment with optional Ollama and a safe fallback.
