# The fallback provides deterministic decisions when Ollama is disabled or fails.
from app.models.claim import InsuranceClaim
from app.models.results import AIDecision


def evaluate_with_rules(claim: InsuranceClaim) -> AIDecision:
    # Combine relevant evidence for transparent keyword-based assessment.
    text = " ".join(
        [claim.diagnosis, claim.treatment, claim.doctor_notes, claim.medical_history]
    ).lower()
    evidence = ["diagnosis", "treatment", "doctor notes", "medical history"]
    ambiguous = [
        "inconclusive", "unclear", "possible", "ambiguous",
        "insufficient", "contradict", "coding inconsistency",
    ]
    cosmetic = ["cosmetic", "appearance only", "elective rhinoplasty"]
    necessary = [
        "heart attack", "myocardial infarction", "emergency", "fracture",
        "cancer", "chemotherapy", "kidney", "dialysis", "acute",
        "pregnancy complication", "diabetes",
    ]
    if len(claim.doctor_notes.strip()) < 20 or any(term in text for term in ambiguous):
        # Uncertain evidence must always be reviewed by a person.
        return AIDecision(
            decision="Escalate", confidence=55,
            reasoning="The submitted clinical evidence is incomplete, ambiguous, or internally inconsistent.",
            recommended_action="A qualified human reviewer should assess the source documents.",
            evidence_used=evidence,
            risk_flags=["Ambiguous or insufficient clinical evidence"],
        )
    if any(term in text for term in cosmetic):
        # This rule requires documentation of functional or urgent need.
        return AIDecision(
            decision="Reject", confidence=94,
            reasoning="The notes describe an elective cosmetic procedure without documented functional impairment or urgent need.",
            recommended_action="Issue a rejection notice subject to human appeal rights.",
            evidence_used=["diagnosis", "treatment", "doctor notes"],
            risk_flags=[],
        )
    if any(term in text for term in necessary):
        # Clear guideline-aligned cases can proceed with high confidence.
        return AIDecision(
            decision="Approve", confidence=92,
            reasoning="The records describe treatment that is consistent with the documented acute or ongoing condition.",
            recommended_action="Proceed to reimbursement and notification.",
            evidence_used=evidence + ["local clinical guidelines"],
            risk_flags=[],
        )
    return AIDecision(
        decision="Escalate", confidence=64,
        reasoning="The evidence does not support a reliable automatic medical-necessity decision.",
        recommended_action="Route the claim to a qualified human reviewer.",
        evidence_used=evidence,
        risk_flags=["No clear guideline match"],
    )
