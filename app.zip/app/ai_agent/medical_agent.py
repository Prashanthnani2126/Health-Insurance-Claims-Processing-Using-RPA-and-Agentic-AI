# This adapter isolates optional Ollama communication from workflow decisions.
import json
import time

from app.ai_agent.fallback_agent import evaluate_with_rules
from app.ai_agent.prompt_template import build_medical_review_prompt
from app.models.claim import InsuranceClaim
from app.models.results import AIDecision
from app.utils.logger import get_logger
from config import settings

logger = get_logger(__name__)


def review_medical_necessity(claim: InsuranceClaim) -> tuple[AIDecision, str, str]:
    # Build the same evidence summary for both model and fallback auditing.
    prompt = build_medical_review_prompt(claim)
    if not settings.use_ollama:
        # Local deterministic operation requires no model service.
        return evaluate_with_rules(claim), prompt, "rule-based-fallback"
    for attempt in range(settings.ollama_retries + 1):
        # Short bounded retries handle temporary local Ollama failures.
        try:
            import ollama

            response = ollama.chat(
                model=settings.ollama_model,
                messages=[{"role": "user", "content": prompt}],
                format="json",
            )
            payload = json.loads(response["message"]["content"])
            # Reject invalid decisions, confidence ranges, or missing explanations.
            return AIDecision.model_validate(payload), prompt, settings.ollama_model
        except Exception as error:
            logger.warning("Ollama attempt %s failed: %s", attempt + 1, error)
            if attempt < settings.ollama_retries:
                time.sleep(min(2 ** attempt, 4))
    logger.warning("Using the validated rule-based fallback for %s", claim.claim_id)
    return evaluate_with_rules(claim), prompt, "rule-based-fallback"
