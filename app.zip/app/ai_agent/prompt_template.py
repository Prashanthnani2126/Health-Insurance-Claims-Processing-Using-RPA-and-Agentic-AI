# Prompt construction gathers all permitted local evidence in one context object.
import json

from app.database.database import fetch_all, get_policy
from app.models.claim import InsuranceClaim
from config import settings


def load_guidelines() -> dict:
    # A missing optional knowledge file results in an empty evidence source.
    if not settings.guidelines_file.exists():
        return {}
    return json.loads(settings.guidelines_file.read_text(encoding="utf-8"))


def build_medical_review_prompt(claim: InsuranceClaim) -> str:
    # Include recent claims for context without exposing unrelated claimants.
    policy = dict(get_policy(claim.policy_number) or {})
    previous = fetch_all(
        """SELECT claim_id, diagnosis, treatment, status FROM claims
        WHERE policy_number=? AND claim_id<>? ORDER BY created_at DESC LIMIT 5""",
        (claim.policy_number, claim.claim_id),
    )
    context = {
        "claim": claim.__dict__,
        "currency": settings.currency_code,
        "policy": policy,
        "previous_claims": previous,
        "local_clinical_guidelines": load_guidelines(),
    }
    # The output contract mirrors the Pydantic validation model.
    return (
        "Academic claims demonstration only. You are not a doctor and this is not "
        "a production medical decision. Assess medical necessity from only the "
        "provided evidence. Escalate incomplete, contradictory, ambiguous, or "
        "low-confidence cases. Return JSON with decision (Approve, Reject, or "
        "Escalate), confidence (0-100), reasoning, recommended_action, "
        "evidence_used (list), and risk_flags (list).\nCONTEXT:\n"
        + json.dumps(context, indent=2, default=str)
    )
