# These transparent indicators request verification and never allege wrongdoing.
from app.models.claim import InsuranceClaim


def assess_risk_indicators(claim: InsuranceClaim) -> list[str]:
    # Return explainable flags that a human assessor can verify independently.
    flags: list[str] = []
    if claim.amount >= 40000:
        # A high value is a review trigger, not evidence of misconduct.
        flags.append("High-value claim: verify invoice and authorisation.")
    if not claim.provider_name:
        flags.append("Provider name is absent.")
    if claim.procedure_code and not any(char.isdigit() for char in claim.procedure_code):
        flags.append("Procedure code format may be inconsistent.")
    if "coding inconsistency" in claim.doctor_notes.lower():
        flags.append("Submitted notes mention a possible coding inconsistency.")
    return flags
