# The RPA workflow runs repeatable rules before any agentic assessment.
from pathlib import Path

from app.database.database import save_audit_log, save_claim
from app.models.results import RPAResult
from app.rpa.claim_reader import read_claims
from app.rpa.document_validator import validate_required_documents
from app.rpa.duplicate_checker import is_duplicate_claim
from app.rpa.fraud_rules import assess_risk_indicators
from app.rpa.policy_checker import calculate_reimbursement, check_policy
from app.utils.logger import get_logger
from config import settings

logger = get_logger(__name__)


def run_rpa_workflow(claim_file: Path, use_ocr: bool = False) -> list[RPAResult]:
    # Process claims independently so one failure does not stop the whole batch.
    results: list[RPAResult] = []
    for claim in read_claims(claim_file, use_ocr):
        try:
            if is_duplicate_claim(claim, settings.database_path):
                # Duplicate records are reported without overwriting the original.
                result = RPAResult(claim, "Rejected", "Duplicate claim detected.")
            else:
                policy_valid, reason = check_policy(claim)
                if not policy_valid:
                    result = RPAResult(claim, "Rejected", reason)
                else:
                    documents_valid, reason = validate_required_documents(claim)
                    if not documents_valid:
                        # Missing documents request information rather than reject.
                        result = RPAResult(
                            claim, "Additional Information Required", reason
                        )
                    else:
                        reimbursement = calculate_reimbursement(claim)
                        flags = assess_risk_indicators(claim)
                        # Eligible claims continue to the separate AI workflow.
                        result = RPAResult(
                            claim, "Eligible",
                            "Eligibility, coverage, and document validation passed.",
                            reimbursement, flags,
                        )
            if result.status != "Rejected" or result.reason != "Duplicate claim detected.":
                save_claim(
                    claim, result.status, result.reimbursement_amount, str(claim_file)
                )
            save_audit_log(
                claim.claim_id, "RPA", result.status, result.reason,
                {"risk_flags": result.risk_flags},
            )
            results.append(result)
        except Exception as error:
            # Log the traceback while returning a readable per-claim error.
            logger.exception("RPA processing failed for %s", claim.claim_id)
            results.append(RPAResult(claim, "Error", str(error)))
    return results
