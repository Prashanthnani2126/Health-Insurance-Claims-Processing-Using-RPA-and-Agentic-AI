# Mandatory-document validation is explicit and easy to audit.
from app.models.claim import InsuranceClaim


def validate_required_documents(claim: InsuranceClaim) -> tuple[bool, str]:
    # Collect every missing item so the claimant receives one complete request.
    missing_documents: list[str] = []

    if not claim.hospital_bill:
        missing_documents.append("hospital bill")
    if not claim.doctor_report:
        missing_documents.append("doctor report")
    if not claim.identity_document:
        missing_documents.append("identity document")
    if not claim.discharge_summary:
        missing_documents.append("discharge summary")

    if missing_documents:
        return False, "Missing documents: " + ", ".join(missing_documents)

    return True, "All required documents are available."
