# Policy checks are deterministic and occur before medical-necessity review.
from datetime import date

from app.database.database import get_policy
from app.models.claim import InsuranceClaim


def check_policy(claim: InsuranceClaim, policy_file=None) -> tuple[bool, str]:
    # Return at the first failed contractual condition with a clear reason.
    policy = get_policy(claim.policy_number)
    if policy is None:
        return False, "Policy number does not exist."
    if not policy["active"]:
        return False, "Policy is inactive."
    if date.fromisoformat(str(policy["expiry_date"])) < date.today():
        return False, "Policy has expired."
    covered = {item.strip().lower() for item in policy["covered_categories"].split("|")}
    # Category matching accepts either the treatment category or diagnosis.
    if claim.treatment_category not in covered and claim.diagnosis not in covered:
        return False, "Treatment category is not covered by the policy."
    if claim.amount > float(policy["maximum_claim_amount"]):
        return False, "Claim amount exceeds the policy limit."
    return True, "Policy is active and the treatment is covered."


def calculate_reimbursement(claim: InsuranceClaim) -> float:
    # Apply the configured policy rate only to the eligible capped amount.
    policy = get_policy(claim.policy_number)
    if policy is None:
        return 0.0
    eligible = min(claim.amount, float(policy["maximum_claim_amount"]))
    return round(eligible * float(policy["reimbursement_rate"]), 2)
