# Duplicate checks use the persistent claim identifier.
from pathlib import Path

from app.database.database import claim_exists
from app.models.claim import InsuranceClaim


def is_duplicate_claim(claim: InsuranceClaim, database_path: Path) -> bool:
    # The path parameter is retained for compatibility with the starter API.
    return claim_exists(claim.claim_id)
