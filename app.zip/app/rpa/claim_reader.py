# Claim ingestion supports structured files and field-labelled PDF documents.
import csv
import json
import re
from pathlib import Path
from typing import Any

from app.models.claim import InsuranceClaim
from app.utils.logger import get_logger

logger = get_logger(__name__)


def _to_bool(value: object) -> bool:
    # Accept common spreadsheet representations of a checked document.
    return str(value).strip().lower() in {"true", "1", "yes", "y"}


def _normalise(row: dict[str, Any]) -> InsuranceClaim:
    # Reject incomplete input early with a readable list of missing fields.
    required = {"claim_id", "patient_name", "policy_number", "diagnosis", "treatment", "amount"}
    missing = sorted(key for key in required if not str(row.get(key, "")).strip())
    if missing:
        raise ValueError("Missing required claim fields: " + ", ".join(missing))
    return InsuranceClaim(
        claim_id=str(row["claim_id"]),
        patient_name=str(row["patient_name"]).strip(),
        policy_number=str(row["policy_number"]),
        diagnosis=str(row["diagnosis"]),
        treatment=str(row["treatment"]).strip(),
        doctor_notes=str(row.get("doctor_notes", "")).strip(),
        medical_history=str(row.get("medical_history", "")).strip(),
        hospital_bill=_to_bool(row.get("hospital_bill", False)),
        doctor_report=_to_bool(row.get("doctor_report", False)),
        identity_document=_to_bool(row.get("identity_document", False)),
        discharge_summary=_to_bool(row.get("discharge_summary", False)),
        amount=float(str(row["amount"]).replace(",", "").replace("$", "")),
        treatment_category=str(row.get("treatment_category", "")),
        service_date=str(row.get("service_date", "")),
        provider_name=str(row.get("provider_name", "")),
        procedure_code=str(row.get("procedure_code", "")),
    )


def read_claims_from_csv(path: Path) -> list[InsuranceClaim]:
    # utf-8-sig also accepts CSV files exported with a byte-order mark.
    with path.open(encoding="utf-8-sig", newline="") as source:
        return [_normalise(row) for row in csv.DictReader(source)]


def read_claims_from_json(path: Path) -> list[InsuranceClaim]:
    # Support a single claim, a plain list, or a top-level claims collection.
    payload = json.loads(path.read_text(encoding="utf-8"))
    records = payload if isinstance(payload, list) else payload.get("claims", [payload])
    return [_normalise(record) for record in records]


def _pdf_text(path: Path, use_ocr: bool = False) -> str:
    # Prefer embedded text because it is quicker and more accurate than OCR.
    import pdfplumber

    with pdfplumber.open(path) as document:
        text = "\n".join(page.extract_text() or "" for page in document.pages)
        if text.strip() or not use_ocr:
            return text
        try:
            # OCR imports stay optional for installations that process only text.
            import cv2
            import numpy as np
            import pytesseract

            chunks = []
            for page in document.pages:
                image = np.array(page.to_image(resolution=200).original)
                gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
                chunks.append(pytesseract.image_to_string(gray))
            return "\n".join(chunks)
        except (ImportError, RuntimeError) as error:
            raise RuntimeError(
                "OCR requires pytesseract, OpenCV, and the Tesseract application."
            ) from error


def read_claims_from_pdf(path: Path, use_ocr: bool = False) -> list[InsuranceClaim]:
    # Academic PDF samples use a simple "Field: value" layout.
    text = _pdf_text(path, use_ocr)
    fields: dict[str, str] = {}
    aliases = {
        "claim id": "claim_id", "patient name": "patient_name",
        "policy number": "policy_number", "diagnosis": "diagnosis",
        "treatment": "treatment", "doctor notes": "doctor_notes",
        "medical history": "medical_history", "amount": "amount",
        "hospital bill": "hospital_bill", "doctor report": "doctor_report",
        "identity document": "identity_document",
        "discharge summary": "discharge_summary",
    }
    for line in text.splitlines():
        # Ignore unrelated headings and retain only recognised claim fields.
        match = re.match(r"^\s*([^:]+):\s*(.+?)\s*$", line)
        if match and match.group(1).strip().lower() in aliases:
            fields[aliases[match.group(1).strip().lower()]] = match.group(2)
    return [_normalise(fields)]


def read_claims(path: Path, use_ocr: bool = False) -> list[InsuranceClaim]:
    # Select an importer from the actual filename extension.
    if not path.exists():
        raise FileNotFoundError(f"Claims file was not found: {path}")
    readers = {
        ".csv": read_claims_from_csv,
        ".json": read_claims_from_json,
        ".pdf": lambda value: read_claims_from_pdf(value, use_ocr),
    }
    try:
        claims = readers[path.suffix.lower()](path)
    except KeyError as error:
        raise ValueError("Supported claim formats are CSV, JSON, and PDF.") from error
    logger.info("Loaded %s claim(s) from %s", len(claims), path)
    return claims
