# Command-line orchestration is kept separate from the web application.
from app.database.database import initialise_database, seed_policies
from app.services.claim_processor import process_claim_file
from app.services.report_service import (
    export_audit_report, export_processed_claims, generate_charts,
    generate_summary_report,
)
from config import settings


def main() -> None:
    # Prepare persistent storage before reading any claims.
    print("HEALTH INSURANCE CLAIMS PROCESSING - ACADEMIC DEMONSTRATION")
    initialise_database()
    seed_policies()
    results = process_claim_file(settings.claims_file)
    # Refresh the assessment artefacts after the complete batch has finished.
    export_processed_claims()
    export_audit_report()
    generate_summary_report()
    generate_charts()
    for result in results:
        # Show a concise result while detailed evidence remains in SQLite.
        print(f"{result['claim_id']}: {result.get('decision', result['rpa_status'])}")
    print(f"Processed {len(results)} claims. See outputs/ and reports/.")
