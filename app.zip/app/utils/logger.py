# Central logging writes the same event to the terminal and an audit-friendly file.
import logging
from pathlib import Path


def get_logger(name: str) -> logging.Logger:
    # Ensure logging succeeds even on the first project run.
    log_directory = Path("outputs")
    log_directory.mkdir(exist_ok=True)

    logger = logging.getLogger(name)

    if logger.handlers:
        # Reusing existing handlers prevents duplicate log lines on imports.
        return logger

    logger.setLevel(logging.INFO)

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )

    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)

    file_handler = logging.FileHandler(
        log_directory / "automation.log",
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    return logger
