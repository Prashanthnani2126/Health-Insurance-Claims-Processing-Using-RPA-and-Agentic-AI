# Plain-text notices make every automatic outcome easy to inspect.
from pathlib import Path

from config import settings


def generate_notice(claim_id: str, status: str, reason: str) -> Path:
    # Select a descriptive filename while retaining a generic status fallback.
    notice_type = {
        "Approved": "approval",
        "Rejected": "rejection",
        "Additional Information Required": "additional_information",
    }.get(status, "status")
    path = settings.output_dir / f"{claim_id}_{notice_type}_notice.txt"
    path.write_text(
        f"Claim {claim_id}\nStatus: {status}\nReason: {reason}\n\n"
        "Academic demonstration notice. Contact a human reviewer for questions or appeal.",
        encoding="utf-8",
    )
    return path
