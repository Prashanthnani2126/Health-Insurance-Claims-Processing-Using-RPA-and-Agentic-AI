# Reporting converts persisted evidence into portable assessment artefacts.
import csv
import json
from pathlib import Path
from typing import Any

from app.database.database import fetch_all, fetch_one
from config import settings


def save_json_result(claim_id: str, result: dict[str, Any]) -> Path:
    # One JSON file per claim provides a simple machine-readable result.
    destination = settings.output_dir / f"{claim_id}_result.json"
    destination.write_text(json.dumps(result, indent=2), encoding="utf-8")
    return destination


def export_processed_claims() -> Path:
    # Export the current database view rather than the unprocessed source CSV.
    rows = fetch_all("SELECT * FROM claims ORDER BY created_at")
    destination = settings.report_dir / "processed_claims.csv"
    if rows:
        with destination.open("w", encoding="utf-8", newline="") as target:
            writer = csv.DictWriter(target, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
    return destination


def export_audit_report() -> Path:
    # Audit rows are ordered chronologically for easier assessment.
    rows = fetch_all("SELECT * FROM audit_logs ORDER BY created_at")
    destination = settings.report_dir / "audit_report.csv"
    if rows:
        with destination.open("w", encoding="utf-8", newline="") as target:
            writer = csv.DictWriter(target, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
    return destination


def generate_summary_report() -> Path:
    # SQL aggregation keeps report totals consistent with the dashboard.
    summary = fetch_one(
        """SELECT COUNT(*) total,
        SUM(status='Approved') approved, SUM(status='Rejected') rejected,
        SUM(status='Escalated') escalated,
        SUM(status='Additional Information Required') additional_information
        FROM claims"""
    ) or {}
    destination = settings.report_dir / "summary_report.json"
    destination.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return destination


def generate_decision_pdf(claim_id: str) -> Path:
    # ReportLab produces a self-contained individual decision report.
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas

    claim = fetch_one("SELECT * FROM claims WHERE claim_id=?", (claim_id,))
    ai = fetch_one(
        "SELECT * FROM ai_decisions WHERE claim_id=? ORDER BY id DESC LIMIT 1",
        (claim_id,),
    )
    if not claim:
        # Avoid producing an empty or misleading report.
        raise ValueError(f"Claim {claim_id} was not found")
    destination = settings.report_dir / f"{claim_id}_decision_report.pdf"
    document = canvas.Canvas(str(destination), pagesize=A4)
    y = 800
    for line in [
        "Health Insurance Claim Decision Report",
        "Academic demonstration - not for real clinical or insurance use",
        f"Claim: {claim_id}",
        f"Policy: {claim['policy_number']}",
        f"Diagnosis: {claim['diagnosis']}",
        f"Treatment: {claim['treatment']}",
        f"Claim amount: {settings.currency_symbol}{claim['amount']:,.2f} {settings.currency_code}",
        f"Reimbursement: {settings.currency_symbol}{claim['reimbursement_amount']:,.2f} {settings.currency_code}",
        f"Final status: {claim['status']}",
        f"AI recommendation: {(ai or {}).get('decision', 'Not assessed')}",
        f"AI confidence: {(ai or {}).get('confidence', 'N/A')}",
    ]:
        # Limit long header fields to the printable page width.
        document.drawString(50, y, str(line)[:100])
        y -= 24
    reasoning = (ai or {}).get("reasoning", "No AI assessment was required.")
    document.drawString(50, y, "Reasoning:")
    y -= 20
    for start in range(0, len(reasoning), 90):
        # Simple fixed-width wrapping is sufficient for this academic report.
        document.drawString(60, y, reasoning[start:start + 90])
        y -= 18
    document.save()
    return destination


def generate_charts() -> list[Path]:
    # Use a non-interactive backend so charts work on servers and batch runs.
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    # Shared visual settings keep all exported analytics presentation-ready.
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.size": 10,
        "axes.titleweight": "bold",
        "axes.titlesize": 15,
        "axes.labelcolor": "#64748b",
        "xtick.color": "#64748b",
        "ytick.color": "#64748b",
    })
    outputs: list[Path] = []
    palette = ["#0f766e", "#0284c7", "#f59e0b", "#ef4444", "#8b5cf6", "#14b8a6"]
    chart_specs = [
        ("outcome_distribution", "SELECT status label, COUNT(*) value FROM claims GROUP BY status", "donut"),
        ("confidence_distribution", "SELECT CAST(confidence / 10 AS INT) * 10 label, COUNT(*) value FROM ai_decisions GROUP BY label", "bar"),
        ("claims_by_diagnosis", "SELECT diagnosis label, COUNT(*) value FROM claims GROUP BY diagnosis ORDER BY value", "horizontal"),
        ("processing_time", "SELECT claim_id label, processing_seconds value FROM processing_metrics", "line"),
    ]
    for name, query, kind in chart_specs:
        # Skip charts with no underlying records.
        rows = fetch_all(query)
        if not rows:
            continue
        figure, axis = plt.subplots(figsize=(8, 4.8), facecolor="white")
        labels = [str(row["label"]) for row in rows]
        values = [float(row["value"]) for row in rows]
        if kind == "donut":
            wedges, _, _ = axis.pie(
                values,
                colors=palette[:len(values)],
                startangle=90,
                wedgeprops={"width": 0.42, "edgecolor": "white", "linewidth": 3},
                autopct=lambda percentage: f"{percentage:.0f}%" if percentage >= 5 else "",
                pctdistance=0.78,
                textprops={"color": "white", "weight": "bold", "fontsize": 9},
            )
            axis.text(0, 0.06, str(int(sum(values))), ha="center", va="center",
                      fontsize=23, weight="bold", color="#132238")
            axis.text(0, -0.13, "claims", ha="center", va="center",
                      fontsize=9, color="#64748b")
            axis.legend(
                wedges, labels, loc="lower center", bbox_to_anchor=(0.5, -0.12),
                ncol=2, frameon=False, fontsize=8,
            )
            axis.set_title("Claim Outcome Distribution", pad=16, color="#132238")
        elif kind == "line":
            axis.plot(
                labels, values, marker="o", markersize=5, linewidth=2.5,
                color="#0f766e", markerfacecolor="white", markeredgewidth=2,
            )
            axis.fill_between(range(len(values)), values, color="#99f6e4", alpha=0.3)
            axis.set_ylabel("Seconds")
            axis.set_title("Processing Time by Claim", pad=16, color="#132238")
            axis.grid(axis="y", color="#e2e8f0", linewidth=0.8)
        elif kind == "horizontal":
            bars = axis.barh(labels, values, color=palette[1], height=0.62)
            axis.bar_label(bars, padding=4, color="#475569", fontsize=9)
            axis.set_title("Claims by Diagnosis", pad=16, color="#132238")
            axis.grid(axis="x", color="#e2e8f0", linewidth=0.8)
        else:
            bars = axis.bar(labels, values, color=palette[1], width=0.62)
            axis.bar_label(bars, padding=4, color="#475569", fontsize=9)
            axis.set_title("AI Confidence Distribution", pad=16, color="#132238")
            axis.set_xlabel("Confidence band (%)")
            axis.grid(axis="y", color="#e2e8f0", linewidth=0.8)
        axis.spines[["top", "right", "left"]].set_visible(False)
        axis.tick_params(axis="x", rotation=28 if kind == "line" else 0)
        figure.tight_layout()
        output = settings.report_dir / f"{name}.png"
        # Close each figure to avoid memory growth during repeated generation.
        figure.savefig(output, dpi=160, bbox_inches="tight", facecolor="white")
        plt.close(figure)
        outputs.append(output)
    rates = fetch_one(
        """SELECT COUNT(*) total, SUM(status='Approved') approved,
        SUM(status='Escalated') escalated FROM claims"""
    )
    if rates and rates["total"]:
        # Rates are calculated from final claim states.
        figure, axis = plt.subplots(figsize=(7, 4.5), facecolor="white")
        values = [
            100 * rates["approved"] / rates["total"],
            100 * rates["escalated"] / rates["total"],
        ]
        bars = axis.bar(
            ["Approval rate", "Escalation rate"],
            values, color=["#0f766e", "#f59e0b"], width=0.55,
        )
        axis.bar_label(bars, labels=[f"{value:.1f}%" for value in values],
                       padding=5, weight="bold", color="#334155")
        axis.set_ylim(0, 100)
        axis.set_ylabel("Percentage")
        axis.set_title("Automation Decision Rates", pad=16, color="#132238")
        axis.grid(axis="y", color="#e2e8f0", linewidth=0.8)
        axis.spines[["top", "right", "left"]].set_visible(False)
        output = settings.report_dir / "approval_escalation_rates.png"
        figure.savefig(output, dpi=160, bbox_inches="tight", facecolor="white")
        plt.close(figure)
        outputs.append(output)
    return outputs
