# Payment creation uses fictional references for the academic demonstration.
from uuid import uuid4

from app.database.database import save_payment
from app.models.claim import InsuranceClaim


def initiate_payment(claim: InsuranceClaim, amount: float | None = None) -> str:
    # A random reference avoids implying a connection to a real payment system.
    payment_reference = "PAY-" + uuid4().hex[:10].upper()

    save_payment(
        claim_id=claim.claim_id,
        payment_reference=payment_reference,
        amount=amount if amount is not None else claim.amount,
    )

    return payment_reference
