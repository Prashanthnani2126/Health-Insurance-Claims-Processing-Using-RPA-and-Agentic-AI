# This service joins the RPA and AI solutions into the To-Be process.
from pathlib import Path
from time import perf_counter

from app.ai_agent.workflow import run_ai_workflow
from app.database.database import save_audit_log, save_claim, save_metric
from app.rpa.workflow import run_rpa_workflow
from app.services.notice_service import generate_notice
from app.services.payment_service import initiate_payment
from app.services.report_service import generate_decision_pdf, save_json_result


def process_claim_file(path: Path, use_ocr: bool = False) -> list[dict]:
    # Return summary dictionaries for CLI output and integration callers.
    records: list[dict] = []
    for rpa in run_rpa_workflow(path, use_ocr):
        started = perf_counter()
        claim = rpa.claim
        record = {
            "claim_id": claim.claim_id,
            "rpa_status": rpa.status,
            "reason": rpa.reason,
            "risk_flags": rpa.risk_flags,
            "reimbursement_amount": rpa.reimbursement_amount,
        }
        route = "RPA"
        if rpa.status == "Eligible":
            # Medical necessity is assessed only after deterministic checks pass.
            ai = run_ai_workflow(claim)
            record.update(ai.model_dump())
            route = "RPA + Agentic AI"
            if ai.decision == "Approve":
                # Automatic approval creates both payment and claimant notice.
                save_claim(claim, "Approved", rpa.reimbursement_amount, str(path))
                record["payment_reference"] = initiate_payment(
                    claim, rpa.reimbursement_amount
                )
                generate_notice(claim.claim_id, "Approved", ai.reasoning)
            elif ai.decision == "Reject":
                # Rejections never create a payment record.
                save_claim(claim, "Rejected", 0, str(path))
                generate_notice(claim.claim_id, "Rejected", ai.reasoning)
            else:
                record["payment_reference"] = None
        elif rpa.status in {"Rejected", "Additional Information Required"}:
            generate_notice(claim.claim_id, rpa.status, rpa.reason)
        elapsed = perf_counter() - started
        # Store processing time regardless of the selected automation route.
        save_metric(claim.claim_id, elapsed, route)
        save_audit_log(claim.claim_id, "Workflow", "Completed", f"Processed in {elapsed:.3f} seconds.")
        save_json_result(claim.claim_id, record)
        if rpa.status != "Error":
            generate_decision_pdf(claim.claim_id)
        records.append(record)
    return records
