# Typed results prevent workflow stages from returning inconsistent shapes.
from dataclasses import dataclass, field
from typing import Literal

from pydantic import BaseModel, Field, field_validator

from app.models.claim import InsuranceClaim


@dataclass
class RPAResult:
    claim: InsuranceClaim
    status: str
    reason: str
    reimbursement_amount: float = 0.0
    risk_flags: list[str] = field(default_factory=list)


class AIDecision(BaseModel):
    # Restrict automatic outcomes to the three assessment decisions.
    decision: Literal["Approve", "Reject", "Escalate"]
    confidence: float = Field(ge=0, le=100)
    reasoning: str
    recommended_action: str
    evidence_used: list[str] = Field(default_factory=list)
    risk_flags: list[str] = Field(default_factory=list)

    @field_validator("reasoning", "recommended_action")
    @classmethod
    def require_meaningful_text(cls, value: str) -> str:
        # Empty model explanations are invalid and must use the fallback path.
        if not value.strip():
            raise ValueError("A decision explanation and action are required")
        return value.strip()
