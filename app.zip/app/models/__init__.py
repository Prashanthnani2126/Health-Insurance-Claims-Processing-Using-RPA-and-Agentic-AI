# Shared domain models are defined in this package.
