# The claim model carries normalised data between automation stages.
from dataclasses import dataclass


@dataclass
class InsuranceClaim:
    claim_id: str
    patient_name: str
    policy_number: str
    diagnosis: str
    treatment: str
    doctor_notes: str
    medical_history: str
    hospital_bill: bool
    doctor_report: bool
    identity_document: bool
    discharge_summary: bool
    amount: float
    treatment_category: str = ""
    service_date: str = ""
    provider_name: str = ""
    procedure_code: str = ""

    def __post_init__(self) -> None:
        # Normalise identifiers and categories at the system boundary.
        self.claim_id = self.claim_id.strip().upper()
        self.policy_number = self.policy_number.strip().upper()
        self.diagnosis = self.diagnosis.strip().lower()
        self.treatment_category = (
            self.treatment_category.strip().lower() or self.diagnosis
        )
        self.amount = round(float(self.amount), 2)
