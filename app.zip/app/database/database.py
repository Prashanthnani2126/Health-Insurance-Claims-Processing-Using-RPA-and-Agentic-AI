# This module provides a small repository layer over the project SQLite file.
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Any, Iterator

from app.models.claim import InsuranceClaim
from app.models.results import AIDecision
from config import settings


def _now() -> str:
    # Store comparable ISO timestamps without database-specific date functions.
    return datetime.now().isoformat(timespec="seconds")


@contextmanager
def connect(database_path: Path | None = None) -> Iterator[sqlite3.Connection]:
    # Row objects allow repository callers to access fields by meaningful names.
    connection = sqlite3.connect(database_path or settings.database_path)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
        # Commit only after the caller finishes its complete operation.
        connection.commit()
    finally:
        connection.close()


def initialise_database(database_path: Path | None = None) -> None:
    # CREATE IF NOT EXISTS makes repeated startup safe.
    with connect(database_path) as connection:
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS policies (
                policy_number TEXT PRIMARY KEY, active INTEGER NOT NULL,
                expiry_date TEXT NOT NULL, covered_categories TEXT NOT NULL,
                maximum_claim_amount REAL NOT NULL,
                reimbursement_rate REAL NOT NULL DEFAULT 0.8
            );
            CREATE TABLE IF NOT EXISTS claims (
                claim_id TEXT PRIMARY KEY, patient_name TEXT NOT NULL,
                policy_number TEXT NOT NULL, diagnosis TEXT NOT NULL,
                treatment TEXT NOT NULL, doctor_notes TEXT NOT NULL DEFAULT '',
                medical_history TEXT NOT NULL DEFAULT '', amount REAL NOT NULL,
                treatment_category TEXT NOT NULL DEFAULT '', service_date TEXT,
                provider_name TEXT, procedure_code TEXT, status TEXT NOT NULL,
                reimbursement_amount REAL NOT NULL DEFAULT 0,
                source_file TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT, claim_id TEXT NOT NULL,
                document_type TEXT NOT NULL, is_present INTEGER NOT NULL,
                UNIQUE(claim_id, document_type)
            );
            CREATE TABLE IF NOT EXISTS ai_decisions (
                id INTEGER PRIMARY KEY AUTOINCREMENT, claim_id TEXT NOT NULL,
                decision TEXT NOT NULL, confidence REAL NOT NULL,
                reasoning TEXT NOT NULL, recommended_action TEXT NOT NULL,
                evidence_used TEXT NOT NULL DEFAULT '[]',
                risk_flags TEXT NOT NULL DEFAULT '[]', prompt_summary TEXT,
                model_name TEXT NOT NULL DEFAULT 'rule-based-fallback',
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS human_reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT, claim_id TEXT NOT NULL,
                ai_decision_id INTEGER, decision TEXT, reviewer_name TEXT,
                reviewer_notes TEXT, status TEXT NOT NULL DEFAULT 'Pending',
                created_at TEXT NOT NULL, reviewed_at TEXT
            );
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT, claim_id TEXT NOT NULL,
                payment_reference TEXT NOT NULL UNIQUE, amount REAL NOT NULL,
                status TEXT NOT NULL DEFAULT 'Scheduled', created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT, claim_id TEXT NOT NULL,
                stage TEXT NOT NULL, status TEXT NOT NULL, message TEXT NOT NULL,
                details TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS processing_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT, claim_id TEXT NOT NULL,
                processing_seconds REAL NOT NULL, automation_route TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            """
        )
        # Additive migrations preserve databases created by the starter project.
        migrations = {
            "claims": {
                "doctor_notes": "TEXT NOT NULL DEFAULT ''",
                "medical_history": "TEXT NOT NULL DEFAULT ''",
                "treatment_category": "TEXT NOT NULL DEFAULT ''",
                "service_date": "TEXT", "provider_name": "TEXT",
                "procedure_code": "TEXT",
                "reimbursement_amount": "REAL NOT NULL DEFAULT 0",
                "source_file": "TEXT", "updated_at": "TEXT NOT NULL DEFAULT ''",
            },
            "ai_decisions": {
                "evidence_used": "TEXT NOT NULL DEFAULT '[]'",
                "risk_flags": "TEXT NOT NULL DEFAULT '[]'",
                "prompt_summary": "TEXT",
                "model_name": "TEXT NOT NULL DEFAULT 'rule-based-fallback'",
            },
            "payments": {"status": "TEXT NOT NULL DEFAULT 'Scheduled'"},
            "audit_logs": {"details": "TEXT NOT NULL DEFAULT '{}'"},
        }
        for table, columns in migrations.items():
            # Inspect each table before applying an additive column migration.
            existing = {
                row["name"]
                for row in connection.execute(f"PRAGMA table_info({table})").fetchall()
            }
            for column, definition in columns.items():
                if column not in existing:
                    connection.execute(
                        f"ALTER TABLE {table} ADD COLUMN {column} {definition}"
                    )


def seed_policies(policy_file: Path | None = None) -> None:
    # The CSV remains easy for assessors to inspect and edit.
    import csv

    path = policy_file or settings.policies_file
    with path.open(encoding="utf-8-sig", newline="") as source, connect() as connection:
        for row in csv.DictReader(source):
            # Re-seeding updates policy rules without creating duplicates.
            connection.execute(
                """INSERT OR REPLACE INTO policies VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    row["policy_number"].strip().upper(),
                    int(row["active"].strip().lower() in {"true", "1", "yes"}),
                    row["expiry_date"],
                    row["covered_categories"],
                    float(row["maximum_claim_amount"]),
                    float(row.get("reimbursement_rate") or settings.reimbursement_rate),
                ),
            )


def save_claim(
    claim: InsuranceClaim,
    status: str,
    reimbursement_amount: float = 0,
    source_file: str = "",
) -> None:
    # Preserve the original creation time while allowing status updates.
    now = _now()
    with connect() as connection:
        connection.execute(
            """INSERT INTO claims (
                claim_id, patient_name, policy_number, diagnosis, treatment,
                doctor_notes, medical_history, amount, treatment_category,
                service_date, provider_name, procedure_code, status,
                reimbursement_amount, source_file, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(claim_id) DO UPDATE SET status=excluded.status,
                reimbursement_amount=excluded.reimbursement_amount,
                updated_at=excluded.updated_at""",
            (
                claim.claim_id, claim.patient_name, claim.policy_number,
                claim.diagnosis, claim.treatment, claim.doctor_notes,
                claim.medical_history, claim.amount, claim.treatment_category,
                claim.service_date, claim.provider_name, claim.procedure_code,
                status, reimbursement_amount, source_file, now, now,
            ),
        )
        for document_type, present in {
            "hospital_bill": claim.hospital_bill,
            "doctor_report": claim.doctor_report,
            "identity_document": claim.identity_document,
            "discharge_summary": claim.discharge_summary,
        }.items():
            # Store each checklist item separately for transparent auditing.
            connection.execute(
                """INSERT OR REPLACE INTO documents
                (claim_id, document_type, is_present) VALUES (?, ?, ?)""",
                (claim.claim_id, document_type, int(present)),
            )


def claim_exists(claim_id: str) -> bool:
    # Claim identifiers provide the deterministic duplicate rule.
    with connect() as connection:
        return connection.execute(
            "SELECT 1 FROM claims WHERE claim_id = ?", (claim_id,)
        ).fetchone() is not None


def get_policy(policy_number: str) -> sqlite3.Row | None:
    # Policy lookup is centralised so validation does not read CSV repeatedly.
    with connect() as connection:
        return connection.execute(
            "SELECT * FROM policies WHERE policy_number = ?", (policy_number,)
        ).fetchone()


def save_ai_decision(
    claim_id: str,
    decision: AIDecision,
    prompt_summary: str = "",
    model_name: str = "rule-based-fallback",
) -> int:
    # Every recommendation is appended so earlier AI advice remains preserved.
    with connect() as connection:
        cursor = connection.execute(
            """INSERT INTO ai_decisions (
                claim_id, decision, confidence, reasoning, recommended_action,
                evidence_used, risk_flags, prompt_summary, model_name, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                claim_id, decision.decision, decision.confidence,
                decision.reasoning, decision.recommended_action,
                json.dumps(decision.evidence_used), json.dumps(decision.risk_flags),
                prompt_summary, model_name, _now(),
            ),
        )
        return int(cursor.lastrowid)


def create_human_review(claim_id: str, ai_decision_id: int) -> None:
    # Avoid adding a second pending task for the same claim.
    with connect() as connection:
        pending = connection.execute(
            "SELECT 1 FROM human_reviews WHERE claim_id=? AND status='Pending'",
            (claim_id,),
        ).fetchone()
        if not pending:
            connection.execute(
                """INSERT INTO human_reviews
                (claim_id, ai_decision_id, status, created_at)
                VALUES (?, ?, 'Pending', ?)""",
                (claim_id, ai_decision_id, _now()),
            )
        connection.execute(
            "UPDATE claims SET status='Escalated', updated_at=? WHERE claim_id=?",
            (_now(), claim_id),
        )


def complete_human_review(
    review_id: int, decision: str, reviewer_name: str, notes: str
) -> str:
    # Human reviewers may make only a final approval or rejection.
    if decision not in {"Approve", "Reject"}:
        raise ValueError("Human decision must be Approve or Reject")
    with connect() as connection:
        row = connection.execute(
            "SELECT claim_id FROM human_reviews WHERE id=?", (review_id,)
        ).fetchone()
        if row is None:
            raise ValueError("Review record was not found")
        # The original linked AI record is never overwritten.
        claim_id = str(row["claim_id"])
        connection.execute(
            """UPDATE human_reviews SET decision=?, reviewer_name=?,
            reviewer_notes=?, status='Completed', reviewed_at=? WHERE id=?""",
            (decision, reviewer_name.strip() or "Academic Reviewer", notes, _now(), review_id),
        )
        connection.execute(
            "UPDATE claims SET status=?, updated_at=? WHERE claim_id=?",
            (decision + "d", _now(), claim_id),
        )
    save_audit_log(claim_id, "Human Review", decision, notes or "Human decision recorded.")
    return claim_id


def save_audit_log(
    claim_id: str, stage: str, status: str, message: str,
    details: dict[str, Any] | None = None,
) -> None:
    # Optional structured details supplement the readable audit message.
    with connect() as connection:
        connection.execute(
            """INSERT INTO audit_logs
            (claim_id, stage, status, message, details, created_at)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (claim_id, stage, status, message, json.dumps(details or {}), _now()),
        )


def save_payment(claim_id: str, payment_reference: str, amount: float) -> None:
    # Idempotency prevents repeated page actions from creating two payments.
    with connect() as connection:
        existing = connection.execute(
            "SELECT 1 FROM payments WHERE claim_id=?", (claim_id,)
        ).fetchone()
        if not existing:
            connection.execute(
                """INSERT INTO payments
                (claim_id, payment_reference, amount, status, created_at)
                VALUES (?, ?, ?, 'Scheduled', ?)""",
                (claim_id, payment_reference, amount, _now()),
            )
            connection.execute(
                "UPDATE claims SET status='Approved', updated_at=? WHERE claim_id=?",
                (_now(), claim_id),
            )


def save_metric(claim_id: str, seconds: float, route: str) -> None:
    # Metrics support processing-time and automation-route analytics.
    with connect() as connection:
        connection.execute(
            """INSERT INTO processing_metrics
            (claim_id, processing_seconds, automation_route, created_at)
            VALUES (?, ?, ?, ?)""",
            (claim_id, seconds, route, _now()),
        )


def fetch_all(query: str, parameters: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
    # Dashboard queries receive serialisable dictionaries instead of SQLite rows.
    with connect() as connection:
        return [dict(row) for row in connection.execute(query, parameters).fetchall()]


def fetch_one(query: str, parameters: tuple[Any, ...] = ()) -> dict[str, Any] | None:
    # Reuse the common conversion logic for optional single-row queries.
    rows = fetch_all(query, parameters)
    return rows[0] if rows else None
